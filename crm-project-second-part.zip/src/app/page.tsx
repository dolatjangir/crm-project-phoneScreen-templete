
import WorkFromHome from "@/SmallScreenData";
import Image from "next/image";

export default function Home() {
  return (
    <>
   
   <WorkFromHome/>
    </>
  );
}
